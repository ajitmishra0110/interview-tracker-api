package com.ajit.leetcode.service;

import com.ajit.leetcode.LeetCodeClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LeetCodeService {

    @Autowired
    private LeetCodeClient client;

    public LeetCodeResponseDTO analyze(String username) {
        String response = client.fetchUserStats(username);

        // parse JSON (use Jackson)

        int easy = ...;
        int medium = ...;
        int hard = ...;

        int total = easy + medium + hard;

        String weakness = (hard < 50) ? "Hard Problems" : "Balanced";

        return new LeetCodeResponseDTO(
                username, total, easy, medium, hard, weakness
        );
    }
}