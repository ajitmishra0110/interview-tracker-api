package com.ajit.leetcode.controller;

import com.ajit.leetcode.service.LeetCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/leetcode")
public class LeetCodeController {

    @Autowired
    private LeetCodeService service;

    @GetMapping("/{username}")
    public ResponseEntity<?> getAnalysis(@PathVariable String username) {
        return ResponseEntity.ok(service.analyze(username));
    }
}